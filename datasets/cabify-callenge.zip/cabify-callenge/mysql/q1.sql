-- Q1. The total sale amount per month, year, and currency. That amount should be divided by 100 and truncated to one decimal.

SELECT 
	YEAR(created_at) AS _Year,
	MONTH(created_at) AS _Month,
    currency AS Currency, 
    TRUNCATE(SUM(amount)/100, 1) AS 'Total Amount'
FROM 
	sales
GROUP BY 
	_Year, _Month, Currency
ORDER BY
	_Year, _Month, Currency;