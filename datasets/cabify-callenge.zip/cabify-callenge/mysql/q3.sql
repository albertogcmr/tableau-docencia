-- The total sale amount per city and country. Excluding those cities whose sales are lower than 1500.
    
SELECT 
	j.city AS City, 
    j.country AS Country, 
	SUM(s.amount) AS 'Total Sale Amount'
FROM
	sales AS s
LEFT JOIN
	sales_entries AS se
ON
	s.sale_id = se.sale_id
LEFT JOIN 
	journeys AS j
ON
	se.journey_id = j.journey_id
GROUP BY 
	City, Country
HAVING 
	SUM(s.amount) < 1500 -- HAVING after group by
ORDER BY
	City, Country;