-- Q2. The total discount per month, year and currency. Excluding data from 2017.

SELECT 
	YEAR(s.created_at) AS _Year,
	MONTH(s.created_at) AS _Month,
    s.currency AS Currency, 
    SUM(se.discount) AS 'Total Discount'
FROM 
	sales AS s
LEFT JOIN 
	sales_entries AS se
ON 
	s.sale_id = se.sale_id
WHERE
	YEAR(s.created_at) != 2017 -- Remember: No alias in WHERE clause
GROUP BY 
	_Year, _Month, Currency 
ORDER BY
	_Year, _Month, Currency; 