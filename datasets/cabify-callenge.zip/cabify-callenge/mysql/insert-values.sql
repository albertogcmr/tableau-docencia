-- Journeys

INSERT INTO `cabify`.`journeys` (`journey_id`, `country`, `city`) VALUES 
('1', 'ES', 'Madrid'), ('2', 'ES', 'Madrid'), ('3', 'ES', 'Madrid'), ('4', 'ES', 'Madrid'),
('5', 'ES', 'Madrid'), ('6', 'ES', 'Madrid'),('7', 'ES', 'Madrid'),('8', 'FR', 'Paris'),
('9', 'FR', 'Paris'),('10', 'FR', 'Paris'),('11', 'FR', 'Paris'),('12', 'GR', 'Berlin'),
('13', 'UK', 'London'),('14', 'UK', 'London'),('15', 'UK', 'London'),('16', 'UK', 'Bristol'),
('17', 'UK', 'Bristol'), ('18', 'UK', 'Bristol'), ('19', 'UK', 'Bristol'), ('20', 'UK', 'Bristol');

-- sales

SELECT * FROM cabify.sales;
INSERT INTO `cabify`.`sales` (`sale_id`, `client_id`, `tax_code`, `currency`, `amount`, `notes`, `created_at`)
VALUES 
(1, 1, 23, 'EUR', 23, 'Lorem Ipsum', '2005-05-13 07:15:31.123456789'),
(2, 1, 23, 'EUR', 23, 'Lorem Ipsum', '2005-06-13 07:15:31.123456789'),
(3, 1, 23, 'EUR', 23, 'Lorem Ipsum', '2005-06-13 07:15:31.123456789'),
(4, 1, 23, 'EUR', 23, 'Lorem Ipsum', '2005-06-13 07:15:31.123456789'),
(5, 2, 23, 'EUR', 23, 'Lorem Ipsum', '2005-06-13 07:15:31.123456789'),
(6, 2, 4, 'EUR', 23, 'Lorem Ipsum', '2005-07-13 07:15:31.123456789'),
(7, 3, 4, 'DOLLAR', 23, 'Lorem Ipsum', '2005-09-13 07:15:31.123456789'),
(8, 3, 4, 'DOLLAR', 23, 'Lorem Ipsum', '2005-09-13 07:15:31.123456789'),
(9, 4, 4, 'DOLLAR', 23, 'Lorem Ipsum', '2006-05-13 07:15:31.123456789'),
(10, 4, 34, 'DOLLAR', 23, 'Lorem Ipsum', '2006-05-13 07:15:31.123456789'),
(11, 4, 44, 'DOLLAR', 23, 'Lorem Ipsum', '2006-06-13 07:15:31.123456789'), 
(12, 4, 34, 'EUR', 23, 'Lorem Ipsum', '2006-06-13 07:15:31.123456789'), 
(17, 4, 34, 'EUR', 23, 'Lorem Ipsum', '2017-06-13 07:15:31.123456789');

-- sales_entries

INSERT INTO `cabify`.`sales_entries` (`sale_entry_id`, `sale_id`, `price`, `discount`, `journey_id`) 
VALUES (1, 1, 44, 24, 1);
INSERT INTO `cabify`.`sales_entries` (`sale_entry_id`, `sale_id`, `price`, `discount`, `journey_id`) 
VALUES (2, 2, 44, 24, 1);
INSERT INTO `cabify`.`sales_entries` (`sale_entry_id`, `sale_id`, `price`, `discount`, `journey_id`) 
VALUES (3, 5, 44, 24, 1);
INSERT INTO `cabify`.`sales_entries` (`sale_entry_id`, `sale_id`, `price`, `discount`, `journey_id`) 
VALUES (4, 3, 44, 24, 1);
INSERT INTO `cabify`.`sales_entries` (`sale_entry_id`, `sale_id`, `price`, `discount`, `journey_id`) 
VALUES (5, 3, 44, 24, 1);
INSERT INTO `cabify`.`sales_entries` (`sale_entry_id`, `sale_id`, `price`, `discount`, `journey_id`) 
VALUES (6, 2, 44, 24, 1);
INSERT INTO `cabify`.`sales_entries` (`sale_entry_id`, `sale_id`, `price`, `discount`, `journey_id`) 
VALUES (7, 5, 44, 24, 1);
INSERT INTO `cabify`.`sales_entries` (`sale_entry_id`, `sale_id`, `price`, `discount`, `journey_id`) 
VALUES (8, 1, 44, 24, 1);
INSERT INTO `cabify`.`sales_entries` (`sale_entry_id`, `sale_id`, `price`, `discount`, `journey_id`) 
VALUES (9, 1, 44, 24, 16);
INSERT INTO `cabify`.`sales_entries` (`sale_entry_id`, `sale_id`, `price`, `discount`, `journey_id`) 
VALUES (10, 1, 44, 24, 17);
INSERT INTO `cabify`.`sales_entries` (`sale_entry_id`, `sale_id`, `price`, `discount`, `journey_id`) 
VALUES (11, 1, 44, 24, 18);
INSERT INTO `cabify`.`sales_entries` (`sale_entry_id`, `sale_id`, `price`, `discount`, `journey_id`) 
VALUES (12, 1, 44, 24, 19);