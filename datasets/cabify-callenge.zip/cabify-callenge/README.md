# cabify-callenge

Challenge para el proceso de admisión de data analytics en Cabify. 

## Entregables

1. Jupyter notebook. 
    * ./cabify-challenge.ipynb
    * ./output/*
    
2. Tableau
    * https://public.tableau.com/profile/alberto.garc.a.cobo#!/vizhome/cabify-challenge/HistoriaAnlisisCabify
    
3. Mysql
    * ./mysql/create-tables.sql
    * ./mysql/insert-values.sql
    * ./mysql/q1.sql
    * ./mysql/q2.sql
    * ./mysql/q3.sql
    
## 1. Jupyter notebook

Fichero de python redactado en jupyter notebook para mejor visualización de las tablas y las gráficas. Viene comentado en cada paso. Pero hay ciertos elementos que quiero recalcar. 

Se pueden observar dos patrones diferentes en las gráficas de los 7 días de la semana: 
1. Tradicionalmente a lo largo de la semana los días siguen un patrón 5+2 (días laborables y fin de semana). En las gráficas que he obtenido, Miércoles y Jueves son semejantes y los otros cinco días son similares entre sí. 
    * Puede que el método **dt.weekday_name** que empleo para obtener los días de la semana es incorrecto. Esto lo compruebo más adelante y funciona correctamente. 
    * Los datos que se me han proporcionado están falseados por alguna razón. Puede que se haya cambiado el dato del año. Donde aparece un Lunes debería ser un Viernes. Y Martes y Miércoles serían Sábado y Domingo. 
2. Los picos de uso a lo largo del día coinciden con las 13:00 y dado que el servidor de cabify se encuentra en Madrid puedo suponer un desfase Lima-Madrid de 7 horas. Estos datos los voy a modificar para progresar con el análisis


## 2. Tableau

En el dashboard de Tableau he intentado representar algunas de las vistas y gráficas que no he hecho en python, ya sea porque en Tableau es mucho más directo o porque permite cierta interactividad. 


## 3. Mysql

Para comprobar que las queries que se me pedían en el enunciado del challenge funcionaban correctamente, me he permitido crear la base de datos con sus tablas y dotarlas de contenido ficticio. Posteriormente en los ficheros: `q1.sql, q2.sql y q3.sql` están los scripts que responden a las preguntas solicitadas. 

